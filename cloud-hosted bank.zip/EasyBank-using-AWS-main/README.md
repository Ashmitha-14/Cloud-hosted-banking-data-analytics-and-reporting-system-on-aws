# EasyBank-using-AWS
Created a responsive website using the AWS servics 
![screencapture-127-0-0-1-5000-confirm-2024-09-18-14_46_55](https://github.com/user-attachments/assets/a707cf97-98ca-4514-8b95-d720a5f28d80)
![screencapture-127-0-0-1-5000-deposit-2024-09-18-14_44_48](https://github.com/user-attachments/assets/327adbfe-2795-496c-b57d-8f8dd4c5b781)
![screencapture-127-0-0-1-5000-contact-2024-09-18-14_37_31](https://github.com/user-attachments/assets/18c04d2d-1fa9-480c-b6eb-314bdb25f433)
![screencapture-127-0-0-1-5000-dashboard-2024-09-18-14_34_37](https://github.com/user-attachments/assets/8452ae3a-e98a-4eeb-b70a-3d4d3030ddc7)
![screencapture-127-0-0-1-5000-dashboard-2024-09-18-14_33_37](https://github.com/user-attachments/assets/2bf80632-fe51-4b78-a47c-5728a481b30f)
![screencapture-127-0-0-1-5000-dashboard-2024-09-18-14_27_00](https://github.com/user-attachments/assets/5f7482ff-f331-420d-a026-5796ab7ded48)
![screencapture-127-0-0-1-5000-login-2024-09-18-14_22_29](https://github.com/user-attachments/assets/d02894e7-b794-4ef7-94fb-a687f10a7d7a)
![screencapture-127-0-0-1-5000-register-2024-09-18-14_22_13](https://github.com/user-attachments/assets/4b0e6183-1c3e-4ac9-bebf-752cd78f7e6d)
![screencapture-127-0-0-1-5000-services-2024-09-18-14_20_48](https://github.com/user-attachments/assets/cb8b8aad-2d16-47e6-84cf-a2eabd071c82)
![screencapture-127-0-0-1-5000-2024-09-18-14_18_39](https://github.com/user-attachments/assets/63a9353e-1a78-497a-8f31-646945f11bd3)
![screencapture-127-0-0-1-5000-transfer-2024-09-18-14_56_16](https://github.com/user-attachments/assets/48720309-eb79-48da-ac17-e2594c7e8740)
